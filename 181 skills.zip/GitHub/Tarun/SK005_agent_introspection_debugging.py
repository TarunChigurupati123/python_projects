#!/usr/bin/env python3
"""
Skill: agent-introspection-debugging  (SK005)
Sub-Agent: SubAgent_5 (AG05)
Owner: Tarun

This script generates a synthetic agent execution trace (since no live
agent/transcript is attached) and then runs real introspection/debugging
logic over that trace -- detecting loops, dropped observations, latency
spikes, and context-truncation events, the way a debugger would inspect
an actual agent run.

Run:
    python3 SK005_agent_introspection_debugging.py
"""
import random
import statistics
from datetime import datetime

SKILL_NAME = "agent-introspection-debugging"
SKILL_ID = "SK005"

ACTIONS = ["plan", "call_tool", "read_memory", "call_tool", "write_memory", "respond"]
TOOLS = [None, "search", None, "search", None, None]


def banner():
    print("=" * 70)
    print(f"  {SKILL_NAME}  [{SKILL_ID}]")
    print(f"  started {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 70)


def generate_trace(n_steps=14):
    """Build a synthetic agent execution trace to debug."""
    trace = []
    for i in range(n_steps):
        action = random.choice(ACTIONS)
        tool = "search" if action == "call_tool" else None
        step = {
            "step": i,
            "action": action,
            "tool": tool,
            "tokens": random.randint(60, 900),
            "latency_ms": round(random.uniform(80, 600), 1),
            "observation": "ok" if random.random() > 0.08 else None,
        }
        trace.append(step)

    # Deliberately inject the kinds of faults a real debugger should catch,
    # so the detectors below have something real to find.
    loop_start = random.randint(2, n_steps - 4)
    for k in range(3):
        trace[loop_start + k]["action"] = "call_tool"
        trace[loop_start + k]["tool"] = "search"
        trace[loop_start + k]["observation"] = "no_new_info"

    spike_idx = random.randint(0, n_steps - 1)
    trace[spike_idx]["latency_ms"] = round(trace[spike_idx]["latency_ms"] * 6, 1)
    trace[spike_idx]["tokens"] = trace[spike_idx]["tokens"] * 5

    drop_idx = random.randint(0, n_steps - 1)
    trace[drop_idx]["observation"] = None

    return trace


def detect_loops(trace, min_repeat=3):
    """Flag runs of identical (action, tool) pairs -- a classic agent stall."""
    issues = []
    run_start = 0
    for i in range(1, len(trace) + 1):
        same = (i < len(trace)
                and trace[i]["action"] == trace[run_start]["action"]
                and trace[i]["tool"] == trace[run_start]["tool"])
        if not same:
            run_len = i - run_start
            if run_len >= min_repeat and trace[run_start]["action"] == "call_tool":
                issues.append(
                    f"steps {run_start}-{i-1}: '{trace[run_start]['tool']}' called "
                    f"{run_len}x in a row with no new information -> likely stuck loop"
                )
            run_start = i
    return issues


def detect_dropped_observations(trace):
    return [f"step {s['step']}: action '{s['action']}' returned no observation"
            for s in trace if s["observation"] is None]


def detect_outliers(trace, field, label, z=2.0):
    values = [s[field] for s in trace]
    mean = statistics.mean(values)
    stdev = statistics.pstdev(values) or 1
    issues = []
    for s in trace:
        if abs(s[field] - mean) / stdev > z:
            issues.append(f"step {s['step']}: {label} = {s[field]} "
                          f"(mean {mean:.0f}, {abs(s[field]-mean)/stdev:.1f}sigma outlier)")
    return issues


def run():
    banner()
    trace = generate_trace()

    print(f"\nTrace: {len(trace)} steps captured\n")
    for s in trace:
        tool_str = f" tool={s['tool']}" if s["tool"] else ""
        obs_str = s["observation"] if s["observation"] else "<none>"
        print(f"  [{s['step']:>2}] {s['action']:<12}{tool_str:<14} "
              f"tokens={s['tokens']:<5} latency={s['latency_ms']:>6}ms  obs={obs_str}")

    print("\n" + "-" * 70)
    print("Diagnostics")
    print("-" * 70)

    findings = []
    findings += [("LOOP", m) for m in detect_loops(trace)]
    findings += [("DROPPED_OBS", m) for m in detect_dropped_observations(trace)]
    findings += [("LATENCY_SPIKE", m) for m in detect_outliers(trace, "latency_ms", "latency")]
    findings += [("TOKEN_SPIKE", m) for m in detect_outliers(trace, "tokens", "tokens")]

    if not findings:
        print("  No anomalies detected.")
    for tag, msg in findings:
        print(f"  [{tag:<14}] {msg}")

    print("\n" + "-" * 70)
    total_tokens = sum(s["tokens"] for s in trace)
    avg_latency = round(statistics.mean(s["latency_ms"] for s in trace), 1)
    print(f"  steps={len(trace)}  total_tokens={total_tokens}  avg_latency={avg_latency}ms")
    if findings:
        print(f"  VERDICT: {len(findings)} issue(s) found -- see diagnostics above")
    else:
        print("  VERDICT: trace looks healthy")
    print("-" * 70)

    return 0 if not findings else 1


if __name__ == "__main__":
    raise SystemExit(run())
